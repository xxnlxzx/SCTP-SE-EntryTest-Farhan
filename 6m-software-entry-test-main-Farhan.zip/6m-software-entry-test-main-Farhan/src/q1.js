/*
    Task 1
    - Create a function that would swap the value of x and y using only x and y as variables.
    - x and y must be numeric.
    - return -1 if x and y is not numeric.
    - print the swapped values in the console

    Task 2
    - invoke the function "swap"
*/
// Task 1:
function swap(x, y){
    if (typeof x === "number" && typeof y === "number") {
    [x, y] = [y, x];

    console.log(`Swapped values: x = ${x} y = ${y}`);
    return [x, y];
} else {
    return -1;
  }
}
// Task 2:
    let x = 10;
    let y = 20;
    
    console.log(swap(x, y));

module.exports = swap;
