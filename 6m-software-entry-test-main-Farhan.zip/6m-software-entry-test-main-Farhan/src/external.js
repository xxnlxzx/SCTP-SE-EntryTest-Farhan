function printSomething(){
    console.log("I am printing something.");
}

module.exports.print = printSomething;