
/*
    Task 1:
    - Import the file `external.js`.
    - Destructure the imported function.
*/

// Task 1:
const { print } = require('./external');

print();